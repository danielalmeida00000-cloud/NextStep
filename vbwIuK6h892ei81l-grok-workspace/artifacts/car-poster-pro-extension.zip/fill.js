const FIELDS = [
  ["Year", "year", "combo"],
  ["Make", "make", "combo"],
  ["Model", "model", "combo"],
  ["Trim", "trim", "combo"],
  ["Mileage", "mileage", "text"],
  ["Price", "price", "text"],
  ["Body style", "body", "combo"],
  ["Exterior color", "exterior", "combo"],
  ["Interior color", "interior", "combo"],
  ["Fuel type", "fuel", "combo"],
  ["Transmission", "transmission", "combo"],
  ["Description", "description", "text"],
];

let packet = null;
let photosTried = false;
let stopped = false;
let running = false;

chrome.storage.local.get(["packet", "packetAt"], (stored) => {
  if (!stored.packet || !stored.packetAt) return;
  if (Date.now() - stored.packetAt > 2 * 60 * 60 * 1000) return;
  packet = stored.packet;
  start();
});

function start() {
  tick();
  const timer = window.setInterval(tick, 900);
  window.setTimeout(() => {
    stopped = true;
    window.clearInterval(timer);
  }, 45000);
}

async function tick() {
  if (!packet || stopped || running) return;
  running = true;
  try {
    await fillOnce();
  } finally {
    running = false;
  }
}

async function fillOnce() {
  if (!packet || stopped) return;
  if (document.querySelector('input[name="email"], input[type="password"]')) {
    overlay("Log into Facebook first. Then open Marketplace again from the extension. It never presses Publish.");
    return;
  }
  clickVehicleType();
  const filled = [];
  for (const [label, key, kind] of FIELDS) {
    const value = packet[key];
    if (!value) continue;
    const input = findInput(label);
    if (!input || input.dataset.cpp === "1") continue;
    if (document.activeElement === input) continue;
    const current = (input.value || "").trim();
    if (current && normalize(current) === normalize(String(value))) {
      input.dataset.cpp = "1";
      continue;
    }
    if (kind === "text") {
      setNativeValue(input, digitsOnly(label) ? String(value).replace(/\D/g, "") : String(value));
      input.dataset.cpp = "1";
      filled.push(label);
    } else {
      const ok = await chooseOption(input, String(value));
      if (ok) {
        input.dataset.cpp = "1";
        filled.push(label);
      }
    }
  }
  if (!photosTried && Array.isArray(packet.imageUrls) && packet.imageUrls.length) {
    photosTried = true;
    void attachPhotos(packet.imageUrls);
  }
  const done = FIELDS.filter(([label, key]) => packet[key] && findInput(label)?.dataset.cpp === "1").map(([label]) => label);
  const waiting = FIELDS.filter(([label, key]) => packet[key] && !findInput(label)).map(([label]) => label);
  const name = packet.title || "This car";
  if (done.length) {
    overlay(
      `${name}: filled ${done.join(", ")}. ${
        waiting.length ? `Still waiting on ${waiting.slice(0, 4).join(", ")}. ` : ""
      }Check it, then you press Publish.`,
    );
  } else {
    overlay(`${name} is ready. Move through Facebook’s screens. This extension fills fields it can see and never presses Publish.`);
  }
  if (filled.length === 0 && done.length === 0) return;
}

function clickVehicleType() {
  if (document.documentElement.dataset.cppType === "1") return;
  const nodes = document.querySelectorAll('[role="button"], [role="radio"], label');
  for (const node of nodes) {
    const text = (node.innerText || "").trim();
    if (text.length > 32) continue;
    if (/^cars?(?:\/|\s+)?trucks?$/i.test(text)) {
      node.click();
      document.documentElement.dataset.cppType = "1";
      return;
    }
  }
}

function findInput(label) {
  const want = label.toLowerCase();
  let best = null;
  let bestScore = 0;
  for (const el of document.querySelectorAll("input, textarea")) {
    if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)) continue;
    if (el instanceof HTMLInputElement && /hidden|file|checkbox|radio|submit/i.test(el.type)) continue;
    const text = labelText(el).toLowerCase();
    if (!text || /search facebook|email|password/.test(text)) continue;
    let score = 0;
    if (text === want) score = 4;
    else if (new RegExp(`(^|\\n|\\b)${escapeReg(want)}(\\b|$)`).test(text) && text.length < want.length + 28) score = 3;
    if (score > bestScore) {
      best = el;
      bestScore = score;
    }
  }
  return best;
}

function labelText(input) {
  const bits = [input.getAttribute("aria-label") || "", input.getAttribute("placeholder") || ""];
  const labelledby = input.getAttribute("aria-labelledby");
  if (labelledby) {
    for (const id of labelledby.split(/\s+/)) {
      const node = document.getElementById(id);
      if (node) bits.push(node.innerText || "");
    }
  }
  const parent = input.closest("label");
  if (parent) bits.push(parent.innerText || "");
  return bits.join(" ").replace(/\s+/g, " ").trim();
}

function setNativeValue(el, value) {
  const prototype = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
  if (descriptor && descriptor.set) descriptor.set.call(el, value);
  else el.value = value;
  el.dispatchEvent(new InputEvent("input", { bubbles: true, data: value, inputType: "insertText" }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

async function chooseOption(input, value) {
  input.focus();
  setNativeValue(input, value);
  input.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true }));
  await sleep(350);
  const want = normalize(value);
  const options = [...document.querySelectorAll('[role="option"], [role="listbox"] [role="menuitem"]')];
  const hit =
    options.find((option) => normalize(option.innerText || "") === want) ||
    options.find((option) => normalize(option.innerText || "").includes(want));
  if (hit) {
    hit.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    hit.click();
    await sleep(80);
    return true;
  }
  const current = normalize(input.value || "");
  return current === want;
}

function attachPhotos(urls) {
  chrome.runtime.sendMessage({ type: "FETCH_IMAGES", urls }, (response) => {
    const images = response && Array.isArray(response.images) ? response.images : [];
    if (!images.length) {
      overlay("Fields are filling. Photos didn’t transfer, so add them on Facebook if they’re missing.");
      return;
    }
    const input = [...document.querySelectorAll('input[type="file"]')].find((el) => {
      const accept = (el.getAttribute("accept") || "").toLowerCase();
      return !accept || accept.includes("image") || accept.includes("jpg") || accept.includes("*");
    });
    if (!input) return;
    const transfer = new DataTransfer();
    images.forEach((image, index) => {
      const bytes = fromBase64(image.b64);
      const type = image.type || "image/jpeg";
      const ext = type.includes("png") ? "png" : "jpg";
      transfer.items.add(new File([bytes], `photo-${index + 1}.${ext}`, { type }));
    });
    input.files = transfer.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
}

function overlay(text) {
  let box = document.getElementById("car-poster-overlay");
  if (!box) {
    box = document.createElement("div");
    box.id = "car-poster-overlay";
    box.style.cssText =
      "position:fixed;z-index:2147483647;left:16px;bottom:16px;max-width:340px;background:#121410;color:#f2efe6;border:1px solid #e4a54b;border-radius:16px;padding:12px 14px;font:14px/1.4 Segoe UI,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.4)";
    document.documentElement.appendChild(box);
  }
  box.textContent = text;
}

function digitsOnly(label) {
  return label === "Price" || label === "Mileage" || label === "Year";
}

function normalize(value) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function escapeReg(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function fromBase64(value) {
  const binary = atob(value || "");
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function sleep(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}
